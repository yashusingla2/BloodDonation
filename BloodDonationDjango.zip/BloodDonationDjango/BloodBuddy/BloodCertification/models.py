from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class BloodCertificate(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    donation_date = models.DateField(auto_now_add=True)
    certificate_id = models.CharField(max_length=20, unique=True)
    issued = models.BooleanField(default=False)

    def __str__(self):
        return f"Certificate for {self.user.username} - {self.certificate_id}"
