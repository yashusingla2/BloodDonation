from django.contrib import admin
from .models import CustomUser, BloodRequest, Donation, Donor

@admin.register(BloodRequest)
class BloodRequestAdmin(admin.ModelAdmin):
    list_display = ('user', 'blood_group', 'location', 'matched', 'request_date')
    search_fields = ('location', 'reason')
    list_filter = ('blood_group', 'matched')
    ordering = ('-request_date',)

@admin.register(Donation)
class DonationAdmin(admin.ModelAdmin):
    list_display = ('user', 'blood_group', 'location', 'available', 'donation_date')
    search_fields = ('location',)
    list_filter = ('blood_group', 'available')
    ordering = ('-donation_date',)

@admin.register(Donor)
class DonorAdmin(admin.ModelAdmin):
    list_display = ('user', 'blood_group', 'location', 'available')
    search_fields = ('user__username', 'location')
    list_filter = ('blood_group', 'available')

@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'is_staff', 'is_superuser')
