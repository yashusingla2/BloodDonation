from django.shortcuts import render, redirect
from django.contrib.auth import login
from .forms import CustomUserCreationForm, BloodRequestForm, DonationForm
from .models import Donor, BloodRequest
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required


def home(request):
    return render(request, 'home.html')

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            return redirect('home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')  # or 'dashboard' if you have that
    else:
        form = AuthenticationForm()
    
    return render(request, 'login.html', {'form': form})

import uuid


@login_required
def donate_blood(request):
    if request.method == 'POST':
        blood_group = request.POST.get('blood_group')
        location = request.POST.get('location')

        Donor.objects.create(
            user=request.user,
            blood_group=blood_group,
            location=location,
            available=True
        )

        # 🔽 Create certificate if not already issued
        if not BloodCertificate.objects.filter(user=request.user).exists():
            BloodCertificate.objects.create(
                user=request.user,
                certificate_id=str(uuid.uuid4())[:8],  # Generate unique ID
                issued=True
            )

        return redirect('request_success')
    return render(request, 'donate_blood.html')

def request_blood(request):
    if request.method == 'POST':
        form = BloodRequestForm(request.POST)
        if form.is_valid():
            blood_request = form.save(commit=False)
            blood_request.user = request.user
            blood_request.name = request.user.username
            blood_request.save()

            # Try to match donor
            donor = Donor.objects.filter(
                blood_group=blood_request.blood_group,
                location=blood_request.location,
                available=True
            ).first()

            if donor:
                blood_request.matched = True
                blood_request.save()

            return redirect('request_success')
    else:
        form = BloodRequestForm()
    return render(request, 'request_blood.html', {'form': form})

def request_success(request):
    return render(request, 'request_success.html')

def about(request):
    return render(request, 'about.html')

def dashboard(request):
    # Get the total number of requests and donors
    total_requests = BloodRequest.objects.count()
    total_donors = Donor.objects.count()

    # Handle filtering logic
    blood_group_filter = request.GET.get('blood_group', '')
    location_filter = request.GET.get('location', '')

    # Filter blood requests based on query parameters
    blood_requests = BloodRequest.objects.all()
    if blood_group_filter:
        blood_requests = blood_requests.filter(blood_group=blood_group_filter)
    if location_filter:
        blood_requests = blood_requests.filter(location__icontains=location_filter)

    # Filter available donors based on query parameters
    donations = Donor.objects.all()
    if blood_group_filter:
        donations = donations.filter(blood_group=blood_group_filter)
    if location_filter:
        donations = donations.filter(location__icontains=location_filter)

    # Pass all the data to the template
    return render(request, 'dashboard.html', {
        'total_requests': total_requests,
        'total_donors': total_donors,
        'blood_requests': blood_requests,
        'donations': donations,
        'blood_group': blood_group_filter,
        'location': location_filter,
    })

from django.contrib.auth.decorators import login_required
from BloodCertification.models import BloodCertificate
from django.contrib import messages

@login_required
def certificate(request):
    try:
        certificate = BloodCertificate.objects.filter(user=request.user).latest('donation_date')
        return render(request, 'certificate.html', {'certificate': certificate})
    except BloodCertificate.DoesNotExist:
        messages.error(request, "No certificate found. Please donate blood first.")
        return redirect('home')



