from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model
from .models import BloodRequest, Donor, Donation

User = get_user_model()

class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class BloodRequestForm(forms.ModelForm):
    class Meta:
        model = BloodRequest
        fields = ['blood_group', 'location', 'reason']

class DonationForm(forms.ModelForm):
    class Meta:
        model = Donation
        fields = ['name', 'blood_group', 'location', 'available']

class DonorForm(forms.ModelForm):
    class Meta:
        model = Donor
        fields = ['blood_group', 'location', 'available']
